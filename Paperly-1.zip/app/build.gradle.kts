plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "com.paperly.app"
    compileSdk = 36
    compileSdkExtension = 19 // androidx.pdf (P2 PDF engine) requires SDK extension >= 19; approved 29 Sep 2026

    defaultConfig {
        applicationId = "com.paperly.app"
        minSdk = 31
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    // Fixed debug key kept in the repo (a debug key protects nothing): every build, local or CI, has the same
    // SHA-1, so Google sign-in stays bound to it. Release signing is separate and never lives in the repo.
    signingConfigs {
        getByName("debug") {
            val fixedKey = file("paperly-debug.keystore")
            if (fixedKey.exists()) {
                storeFile = fixedKey
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        // Measurement-only build for :benchmark (release-like, debug-signed, never shipped).
        create("benchmark") {
            initWith(buildTypes.getByName("release"))
            signingConfig = signingConfigs.getByName("debug")
            matchingFallbacks += listOf("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true // Readium 3.x requires it (P3)
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
            freeCompilerArgs.add("-Xannotation-default-target=param-property") // Hilt @ApplicationContext/@ApplicationScope warning
        }
    }

    buildFeatures { compose = true }

    // Compose UI tests run on the JVM (Robolectric) so CI can check accessibility without a device/emulator.
    testOptions { unitTests { isIncludeAndroidResources = true } }
}

// Crashlytics is wired only when app/google-services.json is present (added when the Firebase project exists),
// so builds stay green without it. Crash reports never include document content.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
    apply(plugin = "com.google.firebase.crashlytics")
}

ksp {
    // Room schema export: migration history stays trackable (App Dev Rules §3)
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.camera.core) // in-app scan camera (Apache-2.0)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.androidx.room.runtime)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.pdf.document.service) // P2 PDF engine (document API only; Viewer = our Compose UI)
    implementation(libs.pdfbox.android) // L3: write highlights into the PDF file (Apache-2.0, pure Java, no .so)
    implementation(libs.tesseract4android) // P10 spike: Bengali OCR trial (Apache-2.0, 16 KB-aligned since 4.8.0)
    implementation(libs.readium.shared) // P3-A spike: EPUB engine candidate (BSD-3)
    implementation(libs.readium.streamer)
    implementation(libs.readium.navigator)
    coreLibraryDesugaring(libs.desugar.jdk.libs)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.crashlytics)
    implementation(libs.firebase.auth) // P8-A: optional Google sign-in
    implementation(libs.firebase.firestore) // P8-B: metadata sync (data layer only)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services)
    implementation(libs.googleid)
    implementation(libs.play.services.auth) // P8-D: AuthorizationClient for the Drive appDataFolder scope

    testImplementation(libs.junit)
    testImplementation(libs.robolectric)
    testImplementation(platform(libs.androidx.compose.bom))
    testImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
