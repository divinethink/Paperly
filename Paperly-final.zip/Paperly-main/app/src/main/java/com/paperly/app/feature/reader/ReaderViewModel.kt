package com.paperly.app.feature.reader

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.paperly.app.R
import com.paperly.app.core.file.DocumentFileStore
import com.paperly.app.core.file.QuickViewStore
import com.paperly.app.core.model.DocumentType
import com.paperly.app.core.perf.PerfTrace
import com.paperly.app.domain.document.Document
import com.paperly.app.domain.document.DocumentRepository
import com.paperly.app.domain.document.ImportResult
import com.paperly.app.domain.ocr.PageOcr
import com.paperly.app.domain.reader.AnnotateStyleStore
import com.paperly.app.domain.reader.AnnotationRepository
import com.paperly.app.domain.reader.OpenResult
import com.paperly.app.domain.reader.ReaderEngine
import com.paperly.app.domain.reader.ReaderPreferences
import com.paperly.app.domain.reader.ReaderStateRepository
import com.paperly.app.domain.reader.ReaderTheme
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Provider
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class ReaderError { NONE, PASSWORD_REQUIRED, UNSUPPORTED, FAILED }

data class ReaderUiState(
    val loading: Boolean = true,
    val document: Document? = null,
    val pageCount: Int = 0,
    val pageAspect: Float = 0f,
    val startPage: Int = 0,
    val error: ReaderError = ReaderError.NONE,
)

@HiltViewModel
@Suppress("LongParameterList", "TooManyFunctions") // Hilt DI collaborators; 11 small state/event handlers
class ReaderViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: DocumentRepository,
    private val readerState: ReaderStateRepository,
    annotationRepository: AnnotationRepository,
    annotateStyleStore: AnnotateStyleStore,
    private val preferences: ReaderPreferences,
    private val fileStore: DocumentFileStore,
    // Provider = lazy: the engine is created only when a PDF is actually opened (Rule #10).
    private val engineProvider: Provider<ReaderEngine>,
    private val pageOcr: PageOcr,
    private val quickStore: QuickViewStore,
) : ViewModel() {

    private val documentId: String = savedStateHandle.get<String>("documentId").orEmpty()

    /** Quick view: a PDF opened from outside and not (yet) in the Library — no progress, bookmarks or annotations. */
    val isQuick: Boolean = QuickViewStore.isToken(documentId)
    private val _uiState = MutableStateFlow(ReaderUiState())
    val uiState: StateFlow<ReaderUiState> = _uiState.asStateFlow()
    private var engine: ReaderEngine? = null
    private val cache = PageBitmapCache()
    private val renderLock = Mutex() // one render at a time keeps peak memory bounded
    private val currentPage = MutableStateFlow<Int?>(null)
    private var lastSaved = -1

    val search = ReaderSearchController(
        scope = viewModelScope,
        engine = { engine },
        pageCount = { _uiState.value.pageCount },
        currentPage = { currentPage.value ?: 0 },
    )

    val textSelect = PdfTextSelectController(viewModelScope) { engine }

    val reflowOcr = ReflowOcrController(viewModelScope, pageOcr, { engine }, documentId)

    val annotations = AnnotationController(viewModelScope, annotationRepository, annotateStyleStore, documentId)

    val theme: StateFlow<ReaderTheme> = preferences.theme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ReaderTheme.AUTO)

    val bookmarkedPages: StateFlow<Set<Int>> =
        (if (documentId.isEmpty()) emptyFlow() else readerState.observeBookmarkedPages(documentId))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptySet())

    init {
        annotations.readOnly = isQuick
        if (!isQuick) textSelect.onMiss = { page, from, to -> annotations.quickMiss(page, from, to) }
        observeProgress()
        viewModelScope.launch {
            val document = PerfTrace.span("reader.open") { loadDocument() }
            if (document == null) {
                _uiState.value = ReaderUiState(loading = false)
                return@launch
            }
            if (!isQuick) repository.markOpened(documentId)
            _uiState.value = if (document.type == DocumentType.PDF || document.type == DocumentType.SCANNED_PDF) {
                openPdf(document)
            } else {
                failed(document, ReaderError.UNSUPPORTED)
            }
            if (_uiState.value.pageCount > 0) search.probe() // after state is set: probe reads pageCount
        }
    }

    private suspend fun loadDocument(): Document? =
        if (isQuick) quickStore.document(documentId) else repository.getDocument(documentId)

    private suspend fun openPdf(document: Document): ReaderUiState {
        val file = (if (isQuick) quickStore.resolve(document.id) else fileStore.resolve(document.id))
            ?: return failed(document, ReaderError.FAILED)
        val pdf = engineProvider.get().also { engine = it }
        return try {
            when (val result = PerfTrace.span("reader.pdf.open") { pdf.open(file) }) {
                is OpenResult.Success -> {
                    val start = (readerState.getSavedPage(document.id) ?: 0).coerceIn(0, result.pageCount - 1)
                    lastSaved = start
                    val aspect = PerfTrace.span("reader.pdf.page0") { pdf.pageAspect(0) }
                    if (aspect == null) {
                        failed(document, ReaderError.FAILED)
                    } else {
                        ReaderUiState(
                            loading = false,
                            document = document,
                            pageCount = result.pageCount,
                            pageAspect = aspect,
                            startPage = start,
                        )
                    }
                }
                OpenResult.PasswordRequired -> failed(document, ReaderError.PASSWORD_REQUIRED)
                OpenResult.Failed -> failed(document, ReaderError.FAILED)
            }
        } catch (e: CancellationException) {
            pdf.close()
            throw e
        }
    }

    /** Debounced (no DB write per scroll frame); [flush] persists immediately on pause. */
    @OptIn(FlowPreview::class)
    private fun observeProgress() {
        viewModelScope.launch {
            currentPage.filterNotNull().debounce(PROGRESS_DEBOUNCE_MS).distinctUntilChanged().collect { save(it) }
        }
    }

    private suspend fun save(page: Int) {
        val count = _uiState.value.pageCount
        if (isQuick || count <= 0 || page == lastSaved) return
        readerState.saveProgress(documentId, page, count)
        lastSaved = page
    }

    fun onPageChanged(page: Int) {
        if (_uiState.value.pageCount > 0) currentPage.value = page
    }

    fun flush() {
        if (isQuick) return
        viewModelScope.launch {
            currentPage.value?.let { save(it) }
            readerState.flushSync(documentId)
        }
    }

    private val _reflow = MutableStateFlow(false)

    /** Reflow (text) view of the PDF instead of page images; not persisted, never touches saved progress. */
    val reflow: StateFlow<Boolean> = _reflow.asStateFlow()

    fun toggleReflow() {
        _reflow.value = !_reflow.value
    }

    fun setTheme(theme: ReaderTheme) {
        viewModelScope.launch { preferences.setTheme(theme) }
    }

    fun toggleBookmark(page: Int) {
        if (isQuick || _uiState.value.pageCount <= 0) return
        viewModelScope.launch { readerState.toggleBookmark(documentId, page) }
    }

    private fun failed(document: Document, error: ReaderError) =
        ReaderUiState(loading = false, document = document, error = error)

    /** Cached page bitmap (LRU), keyed by page + [widthPx] so a zoom-driven higher resolution re-renders. */
    suspend fun pageBitmap(index: Int, widthPx: Int): Bitmap? {
        val pdf = engine ?: return null
        return cache.get(index, widthPx) ?: renderLock.withLock {
            cache.get(index, widthPx) ?: pdf.renderPage(index, widthPx)?.also { cache.put(index, widthPx, it) }
        }
    }

    private val _saved = MutableStateFlow(false)

    /** Quick view only: the PDF has been added to the Library (the menu item then disappears). */
    val saved: StateFlow<Boolean> = _saved.asStateFlow()
    private val _notice = MutableStateFlow<Int?>(null)

    /** One-shot message (string resource) for the UI to show once. */
    val notice: StateFlow<Int?> = _notice.asStateFlow()

    fun clearNotice() {
        _notice.value = null
    }

    /** Quick view -> Library: copies the temporary PDF in; the open Reader keeps reading the temp copy. */
    fun saveToLibrary() {
        val file = quickStore.resolve(documentId) ?: return
        val title = _uiState.value.document?.title ?: "Document"
        viewModelScope.launch {
            val message = when (repository.importPdf(Uri.fromFile(file).toString(), title)) {
                is ImportResult.Success -> R.string.quick_saved
                is ImportResult.Duplicate -> R.string.quick_already_saved
                else -> R.string.quick_save_failed
            }
            if (message != R.string.quick_save_failed) _saved.value = true
            _notice.value = message
        }
    }

    override fun onCleared() {
        if (isQuick) quickStore.delete(documentId) // the temporary copy dies with the Reader
        pageOcr.release()
        engine?.close()
        cache.clear()
    }

    private companion object {
        const val PROGRESS_DEBOUNCE_MS = 800L
        const val STOP_TIMEOUT_MS = 5_000L
    }
}
