package com.paperly.app.data.sync

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.paperly.app.data.auth.await
import com.paperly.app.domain.sync.RemoteMetadataStore
import com.paperly.app.domain.sync.RemoteResult
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

/**
 * Layout: users/{uid}/documents/{documentId}. Writes are `set` on a fixed id, so retries and double-taps are
 * idempotent. Every call has a timeout: Firestore's write task never completes while offline.
 */
@Singleton
class FirestoreMetadataStore @Inject constructor(
    @ApplicationContext private val context: Context,
) : RemoteMetadataStore {

    override suspend fun deleteDocument(uid: String, documentId: String): RemoteResult = call {
        documents(uid).document(documentId).delete().await()
        RemoteResult.OK
    }

    override suspend fun listDocumentIds(uid: String): Set<String>? = try {
        if (!configured()) {
            null
        } else {
            withTimeout(TIMEOUT_MS) {
                documents(uid).get(Source.SERVER).await().documents.map { it.id }.toSet()
            }
        }
    } catch (e: TimeoutCancellationException) {
        null
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private fun documents(uid: String) =
        FirebaseFirestore.getInstance().collection("users").document(uid).collection("documents")

    // Without google-services.json there is no FirebaseApp and getInstance() would throw.
    private fun configured(): Boolean = FirebaseApp.getApps(context).isNotEmpty()

    private suspend fun call(block: suspend () -> RemoteResult): RemoteResult = try {
        if (!configured()) {
            RemoteResult.RETRY
        } else {
            withTimeout(TIMEOUT_MS) { block() }
        }
    } catch (e: TimeoutCancellationException) {
        RemoteResult.RETRY
    } catch (e: CancellationException) {
        throw e
    } catch (e: FirebaseFirestoreException) {
        if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) RemoteResult.DENIED else RemoteResult.RETRY
    } catch (e: Exception) {
        RemoteResult.RETRY
    }

    private companion object {
        const val TIMEOUT_MS = 15_000L
    }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class SyncRemoteModule {
    @Binds
    abstract fun bindRemoteMetadataStore(impl: FirestoreMetadataStore): RemoteMetadataStore
}
