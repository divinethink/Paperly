package com.paperly.app.feature.reader

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.paperly.app.core.file.DocumentFileStore
import com.paperly.app.core.model.DocumentType
import com.paperly.app.core.perf.PerfTrace
import com.paperly.app.data.reader.EpubPublicationOpener
import com.paperly.app.domain.document.DocumentRepository
import com.paperly.app.domain.reader.ReaderStateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication

data class EpubUiState(
    val loading: Boolean = true,
    val isEpub: Boolean = false,
    val title: String = "",
    val publication: Publication? = null,
    val initialLocator: Locator? = null,
    val searchable: Boolean = false,
)

private const val PROGRESS_DEBOUNCE_MS = 800L

/** Decides PDF vs EPUB for the reader route; for EPUB opens the book, resumes, saves progress, bookmarks. */
@OptIn(FlowPreview::class)
@HiltViewModel
class EpubReaderViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: DocumentRepository,
    private val fileStore: DocumentFileStore,
    private val opener: EpubPublicationOpener,
    private val readerState: ReaderStateRepository,
    annotationFactory: EpubAnnotationControllerFactory,
) : ViewModel() {
    private val documentId: String = savedStateHandle.get<String>("documentId").orEmpty()
    private val _uiState = MutableStateFlow(EpubUiState())
    val uiState: StateFlow<EpubUiState> = _uiState.asStateFlow()
    val annotations = annotationFactory.create(viewModelScope, documentId)
    private val latest = MutableStateFlow<Locator?>(null)
    private var searchJob: Job? = null
    private val _searchState = MutableStateFlow(EpubSearchState())
    val searchState: StateFlow<EpubSearchState> = _searchState.asStateFlow()

    /** Live reading position (chapter title + progress) for the bottom bar. */
    val position: StateFlow<Locator?> = latest.asStateFlow()

    val bookmarks: StateFlow<List<String>> =
        (if (documentId.isEmpty()) emptyFlow() else readerState.observeBookmarkLocators(documentId))
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val isBookmarked: StateFlow<Boolean> = combine(bookmarks.map { it.toSet() }, latest) { saved, locator ->
        locator != null && bookmarkKey(locator) in saved
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    init {
        viewModelScope.launch { load() }
        // Debounced like PDF progress: no write on every scroll tick.
        viewModelScope.launch { latest.filterNotNull().debounce(PROGRESS_DEBOUNCE_MS).collect { save(it) } }
    }

    private suspend fun load() {
        val document = repository.getDocument(documentId)
        if (document == null || document.type != DocumentType.EPUB) {
            _uiState.value = EpubUiState(loading = false)
            return
        }
        repository.markOpened(documentId)
        val file = fileStore.resolve(documentId)
        val publication = file?.let { PerfTrace.span("reader.epub.open") { opener.open(it) } }
        _uiState.value = EpubUiState(
            loading = false,
            isEpub = true,
            title = document.title,
            publication = publication,
            initialLocator = decodeLocator(readerState.getSavedLocator(documentId)),
            searchable = publication?.let(::canSearch) == true,
        )
    }

    fun onLocator(locator: Locator) {
        latest.value = withBookEnd(locator, _uiState.value.publication?.readingOrder?.lastOrNull()?.url())
    }

    /** Immediate save (called on ON_PAUSE) so the last position survives app kill. */
    fun flushProgress() {
        viewModelScope.launch {
            latest.value?.let { save(it) }
            readerState.flushSync(documentId)
        }
    }

    fun toggleBookmark() {
        latest.value?.let { viewModelScope.launch { readerState.toggleBookmarkLocator(documentId, bookmarkKey(it)) } }
    }

    /** Stored bookmark JSON is its own identity, so toggling it removes it. */
    fun removeBookmark(json: String) {
        viewModelScope.launch { readerState.toggleBookmarkLocator(documentId, json) }
    }

    /** Cancels any running search; a blank query just clears the results. */
    fun search(query: String) {
        searchJob?.cancel()
        val publication = _uiState.value.publication
        val text = query.trim()
        if (publication == null || text.isEmpty()) {
            _searchState.value = EpubSearchState(query = query)
            return
        }
        _searchState.value = EpubSearchState(query = text, searching = true)
        searchJob = viewModelScope.launch {
            val hits = searchPublication(publication, text).orEmpty()
            _searchState.value = EpubSearchState(query = text, hits = hits, searched = true)
        }
    }

    private suspend fun save(locator: Locator) {
        readerState.saveLocator(documentId, encodeLocator(locator), progressOf(locator))
    }

    override fun onCleared() {
        _uiState.value.publication?.close()
    }
}
