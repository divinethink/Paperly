package com.paperly.app.core.di

import com.paperly.app.data.reader.EnginePdfOpenCheck
import com.paperly.app.data.reader.PdfBoxAnnotationWriter
import com.paperly.app.data.reader.PdfHighlightFileSyncImpl
import com.paperly.app.data.reader.PdfReaderEngine
import com.paperly.app.domain.reader.PdfAnnotationWriter
import com.paperly.app.domain.reader.PdfHighlightFileSync
import com.paperly.app.domain.reader.PdfOpenCheck
import com.paperly.app.domain.reader.ReaderEngine
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/** Unscoped on purpose: every `Provider<ReaderEngine>.get()` is a fresh engine for one open document. */
@Module
@InstallIn(SingletonComponent::class)
abstract class ReaderModule {
    @Binds
    abstract fun bindReaderEngine(impl: PdfReaderEngine): ReaderEngine

    @Binds
    abstract fun bindPdfAnnotationWriter(impl: PdfBoxAnnotationWriter): PdfAnnotationWriter

    @Binds
    abstract fun bindPdfHighlightFileSync(impl: PdfHighlightFileSyncImpl): PdfHighlightFileSync

    @Binds
    abstract fun bindPdfOpenCheck(impl: EnginePdfOpenCheck): PdfOpenCheck
}
