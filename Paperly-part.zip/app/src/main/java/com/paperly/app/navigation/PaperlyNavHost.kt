package com.paperly.app.navigation

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.paperly.app.R
import com.paperly.app.core.ui.adaptive.ScreenSize
import com.paperly.app.core.ui.adaptive.rememberScreenSize
import com.paperly.app.domain.document.LibraryType
import com.paperly.app.feature.library.LIBRARY_TYPE_ARG
import com.paperly.app.feature.library.LibraryNavigation
import com.paperly.app.feature.library.LibraryScreen
import com.paperly.app.feature.reader.ReaderRoute
import com.paperly.app.feature.scanner.LocalOpenScanEditor
import com.paperly.app.feature.scanner.ScanEditScreen
import com.paperly.app.feature.scanner.ScanScreen
import com.paperly.app.feature.settings.SettingsScreen
import com.paperly.app.feature.storage.StorageScreen
import com.paperly.app.feature.trash.TrashScreen

private val FullScreenRoutes = setOf(Routes.READER, Routes.TRASH, Routes.STORAGE, Routes.SCAN_EDIT)

object Routes {
    private const val LIBRARY_PREFIX = "library_"
    const val SCAN = "scan"
    const val SETTINGS = "settings"
    const val TRASH = "trash"
    const val STORAGE = "storage"
    const val READER = "reader/{documentId}"
    fun reader(documentId: String) = "reader/$documentId"
    const val SCAN_EDIT = "scan-edit/{documentId}"
    fun scanEdit(documentId: String) = "scan-edit/$documentId"

    /** One Library destination per tab (Scanned / PDF / EPUB): own back-stack entry, view model and saved state. */
    fun library(type: LibraryType) = LIBRARY_PREFIX + type.key

    fun isLibrary(route: String?) = route?.startsWith(LIBRARY_PREFIX) == true
}

private enum class TopLevel(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    Scanned(Routes.library(LibraryType.SCAN), R.string.nav_scanned, ScannedIcon),
    Pdf(Routes.library(LibraryType.PDF), R.string.nav_pdf, PdfIcon),
    Scan(Routes.SCAN, R.string.nav_scan, Icons.Filled.Add),
    Epub(Routes.library(LibraryType.EPUB), R.string.nav_epub, EpubIcon),
    Settings(Routes.SETTINGS, R.string.nav_settings, Icons.Filled.Settings),
}

private fun NavHostController.navigateTopLevel(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true
    restoreState = true
}

@Composable
fun PaperlyRoot(hasIncomingImport: Boolean = false) {
    val navController = rememberNavController()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    val showNav = currentRoute !in FullScreenRoutes // full-screen flows
    val useRail = rememberScreenSize() != ScreenSize.Compact // adaptive: rail on medium/expanded

    ContinueReadingEffect(navController, currentRoute)
    QuickOpenEffect(navController)

    // Open-With/Share import is handled by Library: make sure it is on screen (whatever screen we were on).
    LaunchedEffect(hasIncomingImport, currentRoute) {
        if (hasIncomingImport && currentRoute != null && !Routes.isLibrary(currentRoute)) {
            navController.navigateTopLevel(Routes.library(LibraryType.PDF))
        }
    }

    Scaffold(
        bottomBar = {
            if (showNav && !useRail) {
                NavigationBar {
                    TopLevel.entries.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = { navController.navigateTopLevel(item.route) },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(stringResource(item.label)) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        Row(Modifier.padding(padding).consumeWindowInsets(padding)) {
            if (showNav && useRail) {
                NavigationRail {
                    TopLevel.entries.forEach { item ->
                        NavigationRailItem(
                            selected = currentRoute == item.route,
                            onClick = { navController.navigateTopLevel(item.route) },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(stringResource(item.label)) },
                        )
                    }
                }
            }
            NavHost(
                navController = navController,
                startDestination = Routes.library(LibraryType.SCAN), // the app always opens on Scanned
                modifier = Modifier.weight(1f),
            ) {
                paperlyDestinations(navController)
            }
        }
    }
}

/** Launcher shortcut "Continue reading": opens the most recently opened document (nothing if none yet). */
@Composable
private fun ContinueReadingEffect(
    navController: NavHostController,
    currentRoute: String?,
    viewModel: ContinueReadingViewModel = hiltViewModel(),
) {
    val pending by viewModel.pending.collectAsStateWithLifecycle()
    LaunchedEffect(pending) {
        if (!pending) return@LaunchedEffect
        val id = viewModel.consumeTarget()
        if (id != null && currentRoute != Routes.READER) navController.navigate(Routes.reader(id))
    }
}

private fun NavGraphBuilder.paperlyDestinations(navController: NavHostController) {
    LibraryType.entries.forEach { libraryType ->
        composable(
            Routes.library(libraryType),
            arguments = listOf(
                navArgument(LIBRARY_TYPE_ARG) {
                    type = NavType.StringType
                    defaultValue = libraryType.key
                },
            ),
        ) {
            LibraryScreen(
                LibraryNavigation(
                    onOpenReader = { navController.navigate(Routes.reader(it)) },
                    onOpenTrash = { navController.navigate(Routes.TRASH) },
                    onOpenStorage = { navController.navigate(Routes.STORAGE) },
                    onShowTab = { navController.navigateTopLevel(Routes.library(it)) },
                ),
            )
        }
    }
    composable(Routes.SCAN) {
        ScanScreen(
            onSaved = { editId ->
                if (editId != null) {
                    navController.navigate(Routes.scanEdit(editId)) // gallery import: straight into the page editor
                } else {
                    navController.navigateTopLevel(Routes.library(LibraryType.SCAN))
                }
            },
        )
    }
    composable(Routes.SETTINGS) { SettingsScreen() }
    composable(Routes.TRASH) { TrashScreen(onBack = { navController.popBackStack() }) }
    composable(Routes.STORAGE) { StorageScreen(onBack = { navController.popBackStack() }) }
    composable(
        Routes.READER,
        arguments = listOf(navArgument("documentId") { type = NavType.StringType }),
    ) {
        // Editing replaces the file, so the Reader (which holds it open) is popped first.
        val openEditor: (String) -> Unit = { id ->
            navController.navigate(Routes.scanEdit(id)) { popUpTo(Routes.READER) { inclusive = true } }
        }
        CompositionLocalProvider(LocalOpenScanEditor provides openEditor) {
            ReaderRoute(onBack = { navController.popBackStack() })
        }
    }
    composable(
        Routes.SCAN_EDIT,
        arguments = listOf(navArgument("documentId") { type = NavType.StringType }),
    ) {
        ScanEditScreen(onDone = { navController.navigateTopLevel(Routes.library(LibraryType.SCAN)) })
    }
}
