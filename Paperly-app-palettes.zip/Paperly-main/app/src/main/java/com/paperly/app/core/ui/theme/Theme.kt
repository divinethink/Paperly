package com.paperly.app.core.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.paperly.app.domain.settings.AppPalette

private val LightColors = lightColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    secondary = Accent,
    onSecondary = Color.White,
    tertiary = Accent,
    onTertiary = Color.White,
    background = AppBackground,
    onBackground = InkText,
    surface = AppBackground,
    onSurface = InkText,
    surfaceVariant = SurfaceSoft,
    onSurfaceVariant = MutedText,
    primaryContainer = Tonal,
    onPrimaryContainer = OnTonal,
    secondaryContainer = Tonal,
    onSecondaryContainer = OnTonal,
    outline = OutlineSoft,
    outlineVariant = DividerSoft,
    error = Danger,
    surfaceBright = PillWhite,
    surfaceContainerLowest = AppBackground,
    surfaceContainerLow = AppBackground,
    surfaceContainer = CardSoft,
    surfaceContainerHigh = SurfaceSoft,
    surfaceContainerHighest = SurfaceSoft,
)

private val DarkColors = darkColorScheme(
    primary = SepiaOnDark,
    onPrimary = Color.Black,
    secondary = SepiaOnDark,
    onSecondary = Color.Black,
    tertiary = SepiaOnDark,
    onTertiary = Color.Black,
    background = NightBackground,
    onBackground = SoftGreyText,
    surface = NightBackground,
    onSurface = SoftGreyText,
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = SoftGreyText,
    primaryContainer = TonalDark,
    onPrimaryContainer = Tonal,
    secondaryContainer = TonalDark,
    onSecondaryContainer = Tonal,
    outline = OutlineDark,
    outlineVariant = DividerDark,
    error = DangerDark,
    surfaceBright = Color(0xFF3A3632),
    surfaceContainerLowest = Color(0xFF0E0E0E),
    surfaceContainerLow = Color(0xFF1A1A1A),
    surfaceContainer = Color(0xFF202020),
    surfaceContainerHigh = Color(0xFF262626),
    surfaceContainerHighest = Color(0xFF2C2C2C),
)

/**
 * Brand palette is the default. An extra [palette] (Meadow, Glacier, Neon Night) wins over Dynamic Color; Dynamic Color
 * (Material You) is optional and OFF by default. minSdk 31 so no API-level check is needed.
 */
@Composable
fun PaperlyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    palette: AppPalette = AppPalette.PAPERLY,
    content: @Composable () -> Unit,
) {
    val picked = paletteColors(palette)
    val colors = when {
        picked != null -> picked
        dynamicColor -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colors, typography = PaperlyTypography, content = content)
}
